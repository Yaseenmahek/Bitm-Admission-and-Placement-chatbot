document.getElementById('send-button').addEventListener('click', async () => {
    const userMessage = document.getElementById('chat-input').value.trim();
    if (!userMessage) return;

    document.getElementById('chat-input').value = '';
    displayMessage('user', userMessage);

    // Show typing indicator
    displayTypingIndicator();

    try {
        const response = await fetch('/chatbot', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: userMessage })
        });

        const data = await response.json();
        removeTypingIndicator();
        displayMessage('bot', data.response);
    } catch (error) {
        removeTypingIndicator();
        displayMessage('bot', 'Sorry, something went wrong. Please try again later.');
    }
});

function displayMessage(sender, message) {
    const chatOutput = document.getElementById('chat-output');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');

    // Add emoji or sticker
    const emojiSpan = document.createElement('span');
    emojiSpan.classList.add('emoji');
    emojiSpan.textContent = sender === 'user' ? '😊' : '🤖';
    messageDiv.appendChild(emojiSpan);

    // Add message text
    const messageSpan = document.createElement('span');
    messageSpan.textContent = message;
    messageDiv.appendChild(messageSpan);

    chatOutput.appendChild(messageDiv);
    chatOutput.scrollTop = chatOutput.scrollHeight;
}

function displayTypingIndicator() {
    const chatOutput = document.getElementById('chat-output');
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typing-indicator';
    typingDiv.classList.add('bot-message');
    typingDiv.textContent = 'Typing...';
    chatOutput.appendChild(typingDiv);
    chatOutput.scrollTop = chatOutput.scrollHeight;
}

function removeTypingIndicator() {
    const typingDiv = document.getElementById('typing-indicator');
    if (typingDiv) typingDiv.remove();
}
