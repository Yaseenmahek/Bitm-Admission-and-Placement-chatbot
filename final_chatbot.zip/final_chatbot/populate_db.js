
use bitm_chatbot_db
db.createCollection("admission_process")
db.createCollection("programs")
db.createCollection("branches")
db.createCollection("placements")

db.admission_process.insertOne({
    details: "The admission process includes submitting an online application, appearing for an entrance exam, document verification, and final admission confirmation. Visit www.bitm.edu.in for more details."
});


db.programs.insertMany([
    { 
        _id: "MCA", 
        name: "Master of Computer Applications", 
        details: "The MCA program focuses on advanced software development and IT management. Duration: 3 years."
    },
    { 
        _id: "MBA", 
        name: "Master of Business Administration", 
        details: "The MBA program provides expertise in management, leadership, and business analytics. Duration: 2 years."
    },
    { 
        _id: "BE", 
        name: "Bachelor of Engineering", 
        details: "The BE program offers specialization in various engineering branches. Duration: 4 years."
    }
]);


db.branches.insertMany([
    { _id: "CSE", program: "BE", name: "Computer Science and Engineering", details: "CSE focuses on software development, data structures, AI, and networking." },
    { _id: "AIML", program: "BE", name: "Artificial Intelligence and Machine Learning", details: "AI-ML covers machine learning algorithms, AI applications, and deep learning." },
    { _id: "EEE", program: "BE", name: "Electrical and Electronics Engineering", details: "EEE focuses on electrical systems, electronics, and power systems." },
    { _id: "ECE", program: "BE", name: "Electronics and Communication Engineering", details: "ECE involves communication systems, VLSI, and embedded systems." },
    { _id: "CIVIL", program: "BE", name: "Civil Engineering", details: "Civil Engineering emphasizes infrastructure development and construction technology." },
    { _id: "MECH", program: "BE", name: "Mechanical Engineering", details: "Mechanical Engineering focuses on design, manufacturing, and thermodynamics." },
    { _id: "CS-DS", program: "BE", name: "Computer Science - Data Science", details: "CS-DS combines data analysis, machine learning, and big data technologies." },
    { _id: "CS-AI", program: "BE", name: "Computer Science - Artificial Intelligence", details: "CS-AI specializes in AI, neural networks, and intelligent systems." }
]);

db.placements.insertMany([
    { program: "BE", branch: "CSE", year: 2024, stats: "97% placements with an average package of 8 LPA." },
    { program: "BE", branch: "AIML", year: 2024, stats: "95% placements with an average package of 7.5 LPA." },
    { program: "BE", branch: "EEE", year: 2024, stats: "90% placements with an average package of 6.5 LPA." },
    { program: "BE", branch: "ECE", year: 2024, stats: "92% placements with an average package of 7 LPA." },
    { program: "BE", branch: "CIVIL", year: 2024, stats: "85% placements with an average package of 5.5 LPA." },
    { program: "BE", branch: "MECH", year: 2024, stats: "88% placements with an average package of 6 LPA." },
    { program: "BE", branch: "CS-DS", year: 2024, stats: "96% placements with an average package of 7.8 LPA." },
    { program: "BE", branch: "CS-AI", year: 2024, stats: "94% placements with an average package of 7.6 LPA." }
]);

db.placements.insertMany([
    { program: "MCA", year: 2021, stats: "95% placements with an average package of 6 LPA." },
    { program: "MCA", year: 2022, stats: "92% placements with an average package of 5.5 LPA." },
    { program: "MCA", year: 2023, stats: "90% placements with an average package of 5 LPA." },
    { program: "MCA", year: 2024, stats: "88% placements with an average package of 4.5 LPA." }
]);

db.placements.insertMany([
    { program: "MBA", year: 2021, stats: "98% placements with an average package of 7 LPA." },
    { program: "MBA", year: 2022, stats: "96% placements with an average package of 6.8 LPA." },
    { program: "MBA", year: 2023, stats: "94% placements with an average package of 6.5 LPA." },
    { program: "MBA", year: 2024, stats: "92% placements with an average package of 6 LPA." }
]);

